# -*- coding: utf-8 -*-
"""
remotion-shorts-creator 설치 및 사용 가이드 PDF 생성
"""
import os, sys
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, PageBreak
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.enums import TA_CENTER, TA_LEFT

# ── 폰트 ─────────────────────────────────────────────────────────────────────
pdfmetrics.registerFont(TTFont("MG",  r"C:\Windows\Fonts\malgun.ttf"))
pdfmetrics.registerFont(TTFont("MGB", r"C:\Windows\Fonts\malgunbd.ttf"))

# ── 색상 ─────────────────────────────────────────────────────────────────────
YELLOW  = colors.HexColor("#FFE500")
DARK    = colors.HexColor("#111111")
DGRAY   = colors.HexColor("#333333")
MGRAY   = colors.HexColor("#777777")
LGRAY   = colors.HexColor("#F5F5F5")
BGRAY   = colors.HexColor("#E8E8E8")
WHITE   = colors.white
ACCENT  = YELLOW

W, H = A4
M = 18 * mm

# ── 스타일 팩토리 ──────────────────────────────────────────────────────────────
def sty(name, font="MG", size=11, leading=18, color=DARK, align=TA_LEFT,
        sb=0, sa=4, li=0, ri=0, bg=None):
    kw = dict(fontName=font, fontSize=size, leading=leading, textColor=color,
              alignment=align, spaceBefore=sb, spaceAfter=sa,
              leftIndent=li, rightIndent=ri)
    if bg: kw["backColor"] = bg
    return ParagraphStyle(name, **kw)

S_TITLE   = sty("title",  "MGB", 28, 36, DARK,  TA_CENTER, sa=8)
S_SUB     = sty("sub",    "MG",  14, 22, MGRAY, TA_CENTER, sa=24)
S_AUTHOR  = sty("author", "MGB", 13, 20, DARK,  TA_CENTER, sa=4)
S_CONTACT = sty("contact","MG",  11, 18, MGRAY, TA_CENTER)
S_H1      = sty("h1",     "MGB", 16, 24, DARK,  sb=14, sa=4)
S_H2      = sty("h2",     "MGB", 12, 20, DARK,  sb=10, sa=4)
S_BODY    = sty("body",   "MG",  11, 18, DARK,  sa=4)
S_BULLET  = sty("bullet", "MG",  11, 18, DARK,  sa=3, li=14)
S_NOTE    = sty("note",   "MG",  10, 16, MGRAY, sa=4)
S_CODE    = sty("code",   "MG",  10, 16, DGRAY, sa=1, li=8, bg=LGRAY)
S_FOOT    = sty("foot",   "MG",   9, 14, MGRAY, TA_CENTER)

# ── 헬퍼 ──────────────────────────────────────────────────────────────────────
def sp(n=6):  return Spacer(1, n)
def hr():     return HRFlowable(width="100%", thickness=1.5,
                                color=YELLOW, spaceAfter=6)

def h1(text):
    return [Paragraph(text, S_H1), hr()]

def h2(text):
    return [Paragraph(text, S_H2)]

def p(text):
    return Paragraph(text, S_BODY)

def note(text):
    return Paragraph("* " + text, S_NOTE)

def code_block(text):
    """코드 블록 — ASCII 전용, 트리 문자 제거"""
    lines = text.strip().split("\n")
    items = []
    for line in lines:
        # 박스 드로잉 문자를 ASCII로 교체
        safe = (line
                .replace("\u251c", "|")   # ├
                .replace("\u2514", "`")   # └
                .replace("\u2500", "-")   # ─
                .replace("\u2502", "|")   # │
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace(" ", "&nbsp;"))
        items.append(Paragraph(safe or "&nbsp;", S_CODE))
    return items

def bullets(items):
    return [Paragraph("  -  " + i, S_BULLET) for i in items]

def make_table(data, col_widths, has_header=True):
    t = Table(data, colWidths=col_widths, repeatRows=(1 if has_header else 0))
    s = [
        ("FONTNAME",     (0,0), (-1,-1), "MG"),
        ("FONTSIZE",     (0,0), (-1,-1), 10),
        ("LEADING",      (0,0), (-1,-1), 16),
        ("TOPPADDING",   (0,0), (-1,-1), 6),
        ("BOTTOMPADDING",(0,0), (-1,-1), 6),
        ("LEFTPADDING",  (0,0), (-1,-1), 8),
        ("RIGHTPADDING", (0,0), (-1,-1), 8),
        ("ROWBACKGROUNDS",(0,1),(-1,-1), [WHITE, LGRAY]),
        ("GRID",         (0,0), (-1,-1), 0.4, BGRAY),
        ("VALIGN",       (0,0), (-1,-1), "MIDDLE"),
    ]
    if has_header:
        s += [
            ("BACKGROUND", (0,0), (-1,0), DARK),
            ("TEXTCOLOR",  (0,0), (-1,0), YELLOW),
            ("FONTNAME",   (0,0), (-1,0), "MGB"),
        ]
    t.setStyle(TableStyle(s))
    return t

# ── 문서 생성 ──────────────────────────────────────────────────────────────────
out = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                   "remotion-shorts-creator-guide.pdf")

doc = SimpleDocTemplate(
    out, pagesize=A4,
    leftMargin=M, rightMargin=M, topMargin=M, bottomMargin=M,
    title="Remotion Shorts Creator - 설치 및 사용 가이드",
    author="부놈",
)

story = []

# ═══════════════════════════════════════════════════════════════════
# 커버 페이지
# ═══════════════════════════════════════════════════════════════════
# 노란 상단 바
cover_bar = Table([["  "]], colWidths=[W - 2*M])
cover_bar.setStyle(TableStyle([
    ("BACKGROUND",    (0,0),(-1,-1), YELLOW),
    ("TOPPADDING",    (0,0),(-1,-1), 8),
    ("BOTTOMPADDING", (0,0),(-1,-1), 8),
]))
story.append(cover_bar)
story.append(sp(40))

# 타이틀
story.append(Paragraph("Remotion Shorts Creator", S_TITLE))
story.append(Paragraph("Claude Code 스킬 &mdash; 설치 및 사용 가이드", S_SUB))

# 구분선
story.append(HRFlowable(width="60%", thickness=2, color=YELLOW,
                         hAlign="CENTER", spaceAfter=24))

# 설명
desc_style = sty("desc", "MG", 12, 20, DGRAY, TA_CENTER, sa=40)
story.append(Paragraph(
    "Claude + 인터넷 연결만으로<br/>"
    "한국어 유튜브 쇼츠 / 미디폼 / 롱폼 영상을<br/>"
    "자동 제작하는 Claude Code 스킬",
    desc_style
))

# 제작자 박스
author_data = [[
    [
        Paragraph("제작자", sty("alabel","MG",10,16,MGRAY,TA_CENTER)),
        sp(4),
        Paragraph("부놈", sty("aname","MGB",16,22,DARK,TA_CENTER)),
        sp(2),
        Paragraph("dev.kwak73@gmail.com", sty("aemail","MG",11,16,DGRAY,TA_CENTER)),
        Paragraph("github.com/devkwak73", sty("agit","MG",11,16,DGRAY,TA_CENTER)),
    ]
]]
atbl = Table(author_data, colWidths=[W - 2*M])
atbl.setStyle(TableStyle([
    ("BACKGROUND",    (0,0),(-1,-1), LGRAY),
    ("TOPPADDING",    (0,0),(-1,-1), 20),
    ("BOTTOMPADDING", (0,0),(-1,-1), 20),
    ("LEFTPADDING",   (0,0),(-1,-1), 0),
    ("BOX",           (0,0),(-1,-1), 1.5, BGRAY),
]))
story.append(atbl)

story.append(PageBreak())

# ═══════════════════════════════════════════════════════════════════
# 1. 개요
# ═══════════════════════════════════════════════════════════════════
story += h1("1. 개요")
story.append(p(
    "이 스킬은 <b>Claude Code</b>에서 동작하는 영상 자동 제작 도구입니다. "
    "대본 작성부터 TTS 생성, Remotion 씬 컴포넌트 생성, MP4 렌더링까지 "
    "모든 과정을 Claude와의 대화만으로 처리합니다."
))
story.append(sp(6))

fmt_data = [
    ["포맷", "길이", "용도"],
    ["숏폼",  "30~60초",   "유튜브 쇼츠 / 인스타 릴스 / 틱톡"],
    ["미디폼","5~10분",    "유튜브 일반 영상"],
    ["롱폼",  "10분 이상", "유튜브 심화 / 강의 영상"],
]
story.append(make_table(fmt_data, [30*mm, 35*mm, W - 2*M - 65*mm]))
story.append(sp(12))

# ═══════════════════════════════════════════════════════════════════
# 2. 필수 조건
# ═══════════════════════════════════════════════════════════════════
story += h1("2. 필수 조건")
req_data = [
    ["소프트웨어",   "버전",  "설치 방법"],
    ["Claude Code", "최신",  "npm install -g @anthropic-ai/claude-code"],
    ["Node.js",     "18+",   "nodejs.org  LTS 버전 설치"],
    ["Python",      "3.8+",  "python.org  (PATH 추가 필수)"],
    ["edge-tts",    "최신",  "pip install edge-tts"],
]
story.append(make_table(req_data, [32*mm, 18*mm, W - 2*M - 50*mm]))
story.append(sp(4))
story.append(note("Claude Code는 Anthropic 계정 및 Claude API 사용이 필요합니다."))
story.append(sp(12))

# ═══════════════════════════════════════════════════════════════════
# 3. 설치 방법
# ═══════════════════════════════════════════════════════════════════
story += h1("3. 설치 방법")

story += h2("방법 1 — Git Clone (권장 / 업데이트 자동)")
story.append(p("터미널에서 아래 명령을 실행하면 설치 완료입니다."))
story.append(sp(4))
story += code_block(
    "# Windows (PowerShell / CMD)\n"
    "git clone https://github.com/devkwak73/remotion-shorts-creator\n"
    '  %USERPROFILE%\\.claude\\skills\\remotion-shorts-creator'
)
story.append(sp(4))
story += code_block(
    "# Mac / Linux\n"
    "git clone https://github.com/devkwak73/remotion-shorts-creator\n"
    "  ~/.claude/skills/remotion-shorts-creator"
)
story.append(sp(10))

story += h2("방법 2 — ZIP 파일 직접 설치")
story += bullets([
    "GitHub 페이지에서  Code -> Download ZIP  클릭",
    "압축 해제 후 폴더를 아래 경로로 복사:",
])
story.append(sp(4))
story += code_block(
    "Windows :  C:\\Users\\[이름]\\.claude\\skills\\remotion-shorts-creator\\\n"
    "Mac/Linux: ~/.claude/skills/remotion-shorts-creator/"
)
story.append(sp(10))

story += h2("업데이트 (Git Clone 설치 시)")
story += code_block(
    "cd ~/.claude/skills/remotion-shorts-creator\n"
    "git pull"
)
story.append(sp(12))

# ═══════════════════════════════════════════════════════════════════
# 4. 사용 방법
# ═══════════════════════════════════════════════════════════════════
story += h1("4. 사용 방법")
story.append(p("Claude Code를 실행한 후 아래 명령을 입력하세요."))
story.append(sp(6))

cmd_data = [
    ["명령어", "설명"],
    ["/remotion-shorts-creator setup",      "최초 1회 — 환경 구성 + 채널 세팅"],
    ["/remotion-shorts-creator new",        "새 영상 제작 (인터뷰 -> 대본 -> 제작)"],
    ["/remotion-shorts-creator run \"주제\"","주제만 입력하면 즉시 제작 (인터뷰 생략)"],
]
story.append(make_table(cmd_data, [80*mm, W - 2*M - 80*mm]))
story.append(sp(12))

# ═══════════════════════════════════════════════════════════════════
# 5. 단계별 흐름
# ═══════════════════════════════════════════════════════════════════
story += h1("5. 단계별 흐름")

story += h2("SETUP — 최초 환경 구성 (1회만 실행)")
story += bullets([
    "Phase 1: Node.js / Python / pip 설치 여부 자동 확인",
    "Phase 2: 채널 이름, 메인 색상, 주요 시청자 등 인터뷰",
    "Phase 3: Remotion 프로젝트 생성 및 의존성 설치",
    "Phase 4: styles.ts, SceneIndicator, ChannelBadge 기본 파일 생성",
])
story.append(sp(10))

story += h2("NEW — 영상 제작 (인터뷰 포함)")
story.append(sp(4))
step_data = [
    ["단계", "작업", "내용"],
    ["Step 1", "인터뷰",          "주제, 포맷, CTA 키워드, 테마 색상 확인"],
    ["Step 2", "대본 AI 생성",    "인터뷰 기반 JSON 대본 자동 생성"],
    ["Step 3", "TTS 생성",        "ko-KR-SunHiNeural 음성으로 MP3 + VTT 생성"],
    ["Step 4", "씬 컴포넌트 생성","visual 타입별 .tsx 씬 파일 자동 생성"],
    ["Step 5", "컴포지션 생성",   "메인 .tsx 및 Root.tsx 업데이트"],
    ["Step 6", "MP4 렌더링",      "npx remotion render 로 최종 영상 출력"],
]
story.append(make_table(step_data, [18*mm, 35*mm, W - 2*M - 53*mm]))
story.append(sp(12))

# ═══════════════════════════════════════════════════════════════════
# 6. 파일 구조
# ═══════════════════════════════════════════════════════════════════
story += h1("6. 스킬 파일 구조")
story += code_block(
    "remotion-shorts-creator/\n"
    "  skill.md              -- YAML 헤더 + 실행 오케스트레이션\n"
    "  refs/\n"
    "    script-rules.md     -- 대본 생성 규칙 (JSON 구조, 씬 타입)\n"
    "    video-rules.md      -- 영상 제작 규칙 (컴포넌트 패턴, 색상)"
)
story.append(sp(6))
story.append(p("스킬은 3개 파일로 역할이 분리되어 있어 수정 시 해당 파일만 편집하면 됩니다."))
story.append(sp(12))

# ═══════════════════════════════════════════════════════════════════
# 7. 색상 테마
# ═══════════════════════════════════════════════════════════════════
story += h1("7. 색상 테마")
color_data = [
    ["색상명", "HEX 코드", "어울리는 주제"],
    ["노랑", "#FFE500", "자동화, 시간 절약, 효율"],
    ["빨강", "#FF4444", "주의, 실수, 위험, 손해"],
    ["초록", "#4ADE80", "수익, 성공, 성장, 돈"],
    ["파랑", "#388BFF", "정보, 데이터, 분석, IT"],
    ["보라", "#A78BFA", "프리미엄, 전략, 브랜딩"],
    ["주황", "#FB923C", "에너지, 도전, 부동산"],
    ["핑크", "#F472B6", "라이프스타일, 뷰티, 육아"],
]
story.append(make_table(color_data, [28*mm, 30*mm, W - 2*M - 58*mm]))
story.append(sp(12))

# ═══════════════════════════════════════════════════════════════════
# 8. 트러블슈팅
# ═══════════════════════════════════════════════════════════════════
story += h1("8. 트러블슈팅")
tr_data = [
    ["문제", "해결"],
    ["edge-tts 명령을 찾을 수 없음",          "python -m edge_tts 로 자동 대체됨 (스크립트 내장)"],
    ["폰트가 적용되지 않음",                   "loadFont() 호출 확인, fontFamily: 'Noto Sans KR' 명시"],
    ["오디오 파일 없음 에러",                  "public/audio-[id]/voiceover.mp3 경로 확인"],
    ["borderTop 이 AbsoluteFill에 무효",      "내부 div에 position:absolute, top:0 으로 대체"],
    ["렌더링이 느림",                          "--concurrency=4 옵션 추가"],
    ["VTT 파싱 결과 0개",                     "타임스탬프 , vs . 확인 -> 정규식 [.,] 사용"],
]
story.append(make_table(tr_data, [62*mm, W - 2*M - 62*mm]))
story.append(sp(20))

# 하단 푸터
footer_tbl = Table(
    [[Paragraph(
        "Remotion Shorts Creator  |  제작: 부놈  |  dev.kwak73@gmail.com  |  github.com/devkwak73",
        S_FOOT
    )]],
    colWidths=[W - 2*M]
)
footer_tbl.setStyle(TableStyle([
    ("BACKGROUND",    (0,0),(-1,-1), LGRAY),
    ("TOPPADDING",    (0,0),(-1,-1), 10),
    ("BOTTOMPADDING", (0,0),(-1,-1), 10),
    ("BOX",           (0,0),(-1,-1), 0.5, BGRAY),
]))
story.append(footer_tbl)

# ── 빌드 ─────────────────────────────────────────────────────────────
doc.build(story)
sys.stdout.buffer.write("PDF 생성 완료: {}\n".format(out).encode("utf-8"))
